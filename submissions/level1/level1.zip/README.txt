Root Cause Analysis - Level 1 submission
==============================================

Run:
    python run.py --level 1

Writes submissions/level1/solution.json, which is the file uploaded
alongside this archive. The generator is fully deterministic - there is no
randomness anywhere - so the same input always produces the same output.

Requires only the Python 3 standard library (no third-party packages).

Layout
------
    run.py                  entry point
    engine/                 shared simulation + scoring
        data.py             loads the plant / animal / unlock datasets
        world.py            grid, terrain, soil, nutrients, dead matter
        sim.py              tick loop (maturity, spread, death, unlocks)
        scoring.py          entropy, coverage and longevity scoring
        actions.py          builds the submission JSON, enforces 20/tick
    solvers/level1.py        the strategy for this level
    problem-statement/      the provided datasets and level file

Strategy notes for this level are in the docstring at the top of
solvers/level1.py.
